import RPi.GPIO as gpio

import time

import sys



class Motor_Module(object):

    def __init__(self):



        gpio.setmode(gpio.BOARD)

        gpio.setwarnings(False)



        pin1 = 12

        pin2 = 16

        pin3 = 18

        pin4 = 32

        pin5 = 36

        pin6 = 38



        self.pin1 = pin1

        self.pin2 = pin2

        self.pin3 = pin3

        self.pin4 = pin4

        self.pin5 = pin5

        self.pin6 = pin6



        gpio.setup(self.pin1, gpio.OUT)

        gpio.setup(self.pin2, gpio.OUT,initial=gpio.LOW)

        gpio.setup(self.pin3, gpio.OUT,initial=gpio.LOW)

        gpio.setup(self.pin4, gpio.OUT)

        gpio.setup(self.pin5, gpio.OUT,initial=gpio.LOW)

        gpio.setup(self.pin6, gpio.OUT,initial=gpio.LOW)



        pwm1 = gpio.PWM(self.pin1, 20000)

        pwm2 = gpio.PWM(self.pin4, 20000)



        pwm1.start(100)

        pwm2.start(100)



        gpio.output(self.pin2, gpio.HIGH)

        gpio.output(self.pin3, gpio.LOW)

        gpio.output(self.pin5, gpio.HIGH)

        gpio.output(self.pin6, gpio.LOW)



        self.pwm1 = pwm1

        self.pwm2 = pwm2



    def aheadlevel1(self):

        self.pwm1.ChangeDutyCycle(90)

        self.pwm2.ChangeDutyCycle(90)



    def aheadlevel2(self):

        self.pwm1.ChangeDutyCycle(93)

        self.pwm2.ChangeDutyCycle(93)



    def aheadlevel3(self):

        self.pwm1.ChangeDutyCycle(96)

        self.pwm2.ChangeDutyCycle(96)



    def aheadlevel4(self):

        self.pwm1.ChangeDutyCycle(99)

        self.pwm2.ChangeDutyCycle(99)



    def left(self):

        self.pwm1.ChangeDutyCycle(99)

        self.pwm2.ChangeDutyCycle(100)



    def right(self):

        self.pwm1.ChangeDutyCycle(100)

        self.pwm2.ChangeDutyCycle(99)



    def stop(self):

        self.pwm1.ChangeDutyCycle(100)

        self.pwm2.ChangeDutyCycle(100)



    def close(self):

        self.pwm1.stop()

        self.pwm2.stop()

        gpio.cleanup()
