# -*- coding:utf8 -

import RPi.GPIO as gpio

import time

import cv2

import numpy as np

import sys

from distance import Ultrasonic_Module

from motor import Motor_Module

from color import Colors
     

ultrasonic=Ultrasonic_Module()

mo=Motor_Module()

co = Colors()

cap = cv2.VideoCapture(0)

n = 0

m = 0

center = 320

distance = 10

a=0



try:

    while(1):

        while(1):

            distance=ultrasonic.getdistance()

            if distance<=0.35:

                mo.stop()

                a=0

            if distance>0.6:

                a=a+1

                if a>=5:

                     a=5

                     break

        if n == 0:

          green_count = co.green()

          if green_count > 50000:

             m = 1

        if n == 1:

          red_count = co.red()

          if red_count > 50000:

             m = 0

             mo.stop()

        n = m

        if n == 1:

          ret, frame = cap.read()

          gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

          retval, dst = cv2.threshold(gray, 0, 255, cv2.THRESH_OTSU)

          dst = cv2.dilate(dst, None, iterations=2)

          dst = cv2.erode(dst, None, iterations=6)



          color = dst[400]

          white_count = np.sum(color == 255)

          white_index = np.where(color == 255)



          if white_count == 0:

              cap.release()

              cv2.destroyAllWindows()

              mo.stop()



          i = 0

          sum = 0

          for i in range(0,white_count-1):

              sum=sum+white_index[0][i]

              center = sum / white_count



          direction = 320-center



          if abs(direction) > 300:

              mo.stop()

          elif abs(direction) < 30:

              mo.aheadlevel4()

          elif direction >= 30:

              mo.left()

              time.sleep(0.15)

              mo.stop()

          elif direction <= -30:

              mo.right()

              time.sleep(0.15)

              mo.stop()

except KeyboardInterrupt:

    cap.release()

    cv2.destroyAllWindows()

    mo.close()


