import RPi.GPIO as gpio

import time



pin1 = 12

pin2 = 16

pin3 = 18

pin4 = 32

pin5 = 36

pin6 = 38



gpio.setmode(gpio.BOARD)



gpio.setup(pin1, gpio.OUT)

gpio.setup(pin2, gpio.OUT)

gpio.setup(pin3, gpio.OUT)

gpio.setup(pin4, gpio.OUT)

gpio.setup(pin5, gpio.OUT)

gpio.setup(pin6, gpio.OUT)



pwm1 = gpio.PWM(pin1, 20000)

pwm2 = gpio.PWM(pin4, 20000)



gpio.output(pin2, gpio.HIGH)

gpio.output(pin3, gpio.LOW)

gpio.output(pin5, gpio.HIGH)

gpio.output(pin6, gpio.LOW)



pwm1.start(0)

pwm2.start(0)



pwm1.ChangeDutyCycle(100)

pwm2.ChangeDutyCycle(100)



pwm1.stop()

pwm2.stop()



gpio.cleanup()


