import time

import sys

class Colors(object):

    def _init_(self):

        ret, frame = cap.read()

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        self.frame = frame

        self.hsv = hsv

    def red(self):

        red_lower = np.array([35,43,46])

        red_upper = np.array([77,255,255])

        red_mask = cv2.inRange(self.hsv, red_lower, red_upper)

        red_res = cv2.bitwise_and(self.frame, self.frame, mask=red_mask)

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))

        red_closing = cv2.morphologyEx(red_res, cv2.MORPH_CLOSE, kernel)

        red_gray = cv2.cvtColor(red_closing, cv2.COLOR_BGR2GRAY)

        (thresh2, red_bw) = cv2.threshold(red_gray, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

        red_black = cv2.countNonZero(red_bw)

        return red_black

     def green(self):

        green_lower = np.array([0,43,46])

        green_upper = np.array([10,255,255])

        green_mask = cv2.inRange(self.hsv, green_lower, green_upper)

        green_res = cv2.bitwise_and(self.frame, self.frame, mask=green_mask)

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))

        green_closing = cv2.morphologyEx(green_res, cv2.MORPH_CLOSE, kernel)

        green_gray = cv2.cvtColor(green_closing, cv2.COLOR_BGR2GRAY)

        (thresh2, green_bw) = cv2.threshold(green_gray, 128, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

        green_black = cv2.countNonZero(green_bw)

        return green_black