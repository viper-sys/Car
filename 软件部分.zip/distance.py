import RPi.GPIO as gpio

import time

class Ultrasonic_Module(object):

    def __init__(self):

        gpio.setmode(gpio.BOARD)

        gpio.setwarnings(False)



        trig_pin = 29

        echo_pin = 31



        self.trig_pin=trig_pin

        self.echo_pin=echo_pin



        gpio.setup(self.trig_pin,gpio.OUT,initial=gpio.LOW)

        gpio.setup(self.echo_pin,gpio.IN)



    def getdistance(self):

        time.sleep(0.01)

        gpio.output(self.trig_pin,gpio.HIGH)

        time.sleep(0.000015)

        gpio.output(self.trig_pin,gpio.LOW)



        while not gpio.input(self.echo_pin):

            pass

        t1=time.time() 

        while gpio.input(self.echo_pin):

            pass

        t2=time.time()

        distance=(t2-t1)*340/2

        return distance
